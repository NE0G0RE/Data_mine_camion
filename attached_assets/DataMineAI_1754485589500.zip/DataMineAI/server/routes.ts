import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTruckSchema, insertScrapingConfigSchema, insertSocialMentionSchema, insertEquipementSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Truck routes
  app.get("/api/trucks", async (req, res) => {
    try {
      const trucks = await storage.getTrucks();
      res.json(trucks);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des camions" });
    }
  });

  app.get("/api/trucks/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Paramètre de recherche manquant" });
      }
      const trucks = await storage.searchTrucks(query);
      res.json(trucks);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la recherche" });
    }
  });

  app.get("/api/trucks/:id", async (req, res) => {
    try {
      const truck = await storage.getTruck(req.params.id);
      if (!truck) {
        return res.status(404).json({ message: "Camion non trouvé" });
      }
      res.json(truck);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération du camion" });
    }
  });

  app.post("/api/trucks", async (req, res) => {
    try {
      const truckData = insertTruckSchema.parse(req.body);
      
      // Check if immatriculation already exists
      const existingTruck = await storage.getTruckByImmatriculation(truckData.immatriculation);
      if (existingTruck) {
        return res.status(400).json({ message: "Cette immatriculation existe déjà" });
      }
      
      const truck = await storage.createTruck(truckData);
      res.status(201).json(truck);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de la création du camion" });
    }
  });

  app.patch("/api/trucks/:id", async (req, res) => {
    try {
      const truckData = insertTruckSchema.partial().parse(req.body);
      const truck = await storage.updateTruck(req.params.id, truckData);
      if (!truck) {
        return res.status(404).json({ message: "Camion non trouvé" });
      }
      res.json(truck);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de la mise à jour du camion" });
    }
  });

  app.delete("/api/trucks/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteTruck(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Camion non trouvé" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la suppression du camion" });
    }
  });

  // Scraping config routes
  app.get("/api/scraping-configs", async (req, res) => {
    try {
      const configs = await storage.getScrapingConfigs();
      res.json(configs);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des configurations" });
    }
  });

  app.post("/api/scraping-configs", async (req, res) => {
    try {
      const configData = insertScrapingConfigSchema.parse(req.body);
      const config = await storage.createScrapingConfig(configData);
      res.status(201).json(config);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de la création de la configuration" });
    }
  });

  // Social mentions routes
  app.get("/api/social-mentions", async (req, res) => {
    try {
      const mentions = await storage.getSocialMentions();
      res.json(mentions);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des mentions" });
    }
  });

  app.post("/api/social-mentions", async (req, res) => {
    try {
      const mentionData = insertSocialMentionSchema.parse(req.body);
      const mention = await storage.createSocialMention(mentionData);
      res.status(201).json(mention);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de la création de la mention" });
    }
  });

  // Equipment routes
  app.get("/api/equipements", async (req, res) => {
    try {
      const equipements = await storage.getEquipements();
      res.json(equipements);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des équipements" });
    }
  });

  app.post("/api/equipements", async (req, res) => {
    try {
      const equipementData = insertEquipementSchema.parse(req.body);
      const equipement = await storage.createEquipement(equipementData);
      res.status(201).json(equipement);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de la création de l'équipement" });
    }
  });

  app.put("/api/equipements/:id", async (req, res) => {
    try {
      const equipementData = insertEquipementSchema.partial().parse(req.body);
      const equipement = await storage.updateEquipement(req.params.id, equipementData);
      if (!equipement) {
        return res.status(404).json({ message: "Équipement non trouvé" });
      }
      res.json(equipement);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de la mise à jour de l'équipement" });
    }
  });

  // Stats endpoint
  app.get("/api/stats", async (req, res) => {
    try {
      const trucks = await storage.getTrucks();
      const stats = {
        totalTrucks: trucks.length,
        okCount: trucks.filter(t => t.statut_global === "vert").length,
        problemCount: trucks.filter(t => t.statut_global === "rouge").length,
        pendingCount: trucks.filter(t => t.statut_global === "gris").length
      };
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors du calcul des statistiques" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
