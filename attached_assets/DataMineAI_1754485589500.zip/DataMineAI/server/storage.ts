import { type User, type InsertUser, type Truck, type InsertTruck, type ScrapingConfig, type InsertScrapingConfig, type SocialMention, type InsertSocialMention, type Equipement, type InsertEquipement } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Truck methods
  getTrucks(): Promise<Truck[]>;
  getTruck(id: string): Promise<Truck | undefined>;
  getTruckByImmatriculation(immatriculation: string): Promise<Truck | undefined>;
  createTruck(truck: InsertTruck): Promise<Truck>;
  updateTruck(id: string, truck: Partial<InsertTruck>): Promise<Truck | undefined>;
  deleteTruck(id: string): Promise<boolean>;
  searchTrucks(query: string): Promise<Truck[]>;

  // Scraping config methods
  getScrapingConfigs(): Promise<ScrapingConfig[]>;
  createScrapingConfig(config: InsertScrapingConfig): Promise<ScrapingConfig>;
  updateScrapingConfig(id: string, config: Partial<InsertScrapingConfig>): Promise<ScrapingConfig | undefined>;
  deleteScrapingConfig(id: string): Promise<boolean>;

  // Social mention methods
  getSocialMentions(): Promise<SocialMention[]>;
  createSocialMention(mention: InsertSocialMention): Promise<SocialMention>;

  // Equipment methods
  getEquipements(): Promise<Equipement[]>;
  createEquipement(equipement: InsertEquipement): Promise<Equipement>;
  updateEquipement(id: string, equipement: Partial<InsertEquipement>): Promise<Equipement | undefined>;
  deleteEquipement(id: string): Promise<boolean>;
}

function calculateTruckStatus(truck: InsertTruck): {
  statut_etat: string;
  statut_truck4u: string;
  statut_tablette: string;
  statut_materiel: string;
  statut_global: string;
} {
  // État - Demande d'Achat et Commande
  let statutEtat = "gris";
  if (truck.numero_demande_achat || truck.numero_commande_achat) {
    if (truck.da_valide && truck.validation_bonne_reception) {
      statutEtat = "vert";
    } else {
      statutEtat = "rouge";
    }
  }

  // État Truck4U
  let statutTruck4u = "gris";
  if (truck.installe_par || truck.numero_truck4u) {
    if (truck.parametrage_realise && 
        truck.donnees_localisation_fonctionnelles && 
        truck.remontees_statut_conduite_fonctionnelles && 
        truck.telechargement_memoire_masse_fonctionnel) {
      statutTruck4u = "vert";
    } else {
      statutTruck4u = "rouge";
    }
  }

  // État Tablette
  let statutTablette = "gris";
  if (truck.tablette_presente) {
    if (truck.tablette_fonctionnelle && truck.compatibilite_tablette) {
      const deliverUpOk = truck.besoin_appli_deliverup ? truck.deliverup_fonctionnel : true;
      statutTablette = deliverUpOk ? "vert" : "rouge";
    } else {
      statutTablette = "rouge";
    }
  }

  // État Matériel
  let statutMateriel = "gris";
  const hasEquipment = truck.camera_cabine_telematics || truck.dashcam || (truck.numero_pda && truck.numero_pda.length > 0);
  if (hasEquipment) {
    const equipmentWorking = (!truck.camera_cabine_telematics || truck.camera_fonctionnelle) &&
                           (!truck.dashcam || truck.dashcam_fonctionnelle) &&
                           (!truck.numero_pda || truck.pda_fonctionnel);
    statutMateriel = equipmentWorking && truck.test_ok ? "vert" : "rouge";
  }

  // Statut Global
  const statuses = [statutEtat, statutTruck4u, statutTablette, statutMateriel];
  let statutGlobal = "gris";
  
  if (statuses.some(s => s === "rouge")) {
    statutGlobal = "rouge";
  } else if (statuses.some(s => s === "vert")) {
    statutGlobal = "vert";
  }

  return {
    statut_etat: statutEtat,
    statut_truck4u: statutTruck4u,
    statut_tablette: statutTablette,
    statut_materiel: statutMateriel,
    statut_global: statutGlobal
  };
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private trucks: Map<string, Truck>;
  private scrapingConfigs: Map<string, ScrapingConfig>;
  private socialMentions: Map<string, SocialMention>;
  private equipements: Map<string, Equipement>;

  constructor() {
    this.users = new Map();
    this.trucks = new Map();
    this.scrapingConfigs = new Map();
    this.socialMentions = new Map();
    this.equipements = new Map();
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Truck methods
  async getTrucks(): Promise<Truck[]> {
    return Array.from(this.trucks.values());
  }

  async getTruck(id: string): Promise<Truck | undefined> {
    return this.trucks.get(id);
  }

  async getTruckByImmatriculation(immatriculation: string): Promise<Truck | undefined> {
    return Array.from(this.trucks.values()).find(
      (truck) => truck.immatriculation === immatriculation
    );
  }

  async createTruck(insertTruck: InsertTruck): Promise<Truck> {
    const id = randomUUID();
    const status = calculateTruckStatus(insertTruck);
    const truck: Truck = {
      id,
      immatriculation: insertTruck.immatriculation,
      modele: insertTruck.modele,
      marque: insertTruck.marque,
      
      // État - Demande d'Achat et Commande
      numero_demande_achat: insertTruck.numero_demande_achat ?? null,
      date_demande_achat: insertTruck.date_demande_achat ?? null,
      da_valide: insertTruck.da_valide ?? null,
      numero_commande_achat: insertTruck.numero_commande_achat ?? null,
      date_commande_achat: insertTruck.date_commande_achat ?? null,
      date_reception_commande: insertTruck.date_reception_commande ?? null,
      validation_bonne_reception: insertTruck.validation_bonne_reception ?? null,
      
      // État Truck4U
      installe_par: insertTruck.installe_par ?? null,
      date_installation_truck4u: insertTruck.date_installation_truck4u ?? null,
      parametrage_realise: insertTruck.parametrage_realise ?? null,
      parametrage_par: insertTruck.parametrage_par ?? null,
      donnees_localisation_fonctionnelles: insertTruck.donnees_localisation_fonctionnelles ?? null,
      remontees_statut_conduite_fonctionnelles: insertTruck.remontees_statut_conduite_fonctionnelles ?? null,
      telechargement_memoire_masse_fonctionnel: insertTruck.telechargement_memoire_masse_fonctionnel ?? null,
      numero_truck4u: insertTruck.numero_truck4u ?? null,
      
      // État Tablette
      tablette_presente: insertTruck.tablette_presente ?? null,
      type_tablette: insertTruck.type_tablette ?? null,
      imei_tablette: insertTruck.imei_tablette ?? null,
      tablette_fonctionnelle: insertTruck.tablette_fonctionnelle ?? null,
      compatibilite_tablette: insertTruck.compatibilite_tablette ?? null,
      besoin_appli_deliverup: insertTruck.besoin_appli_deliverup ?? null,
      deliverup_fonctionnel: insertTruck.deliverup_fonctionnel ?? null,
      application_specifique_client: insertTruck.application_specifique_client ?? null,
      raison_non_installe: insertTruck.raison_non_installe ?? null,
      besoin_autre_appli: insertTruck.besoin_autre_appli ?? null,
      autre_appli_installee: insertTruck.autre_appli_installee ?? null,
      
      // État Matériel
      camera_cabine_telematics: insertTruck.camera_cabine_telematics ?? null,
      camera_fonctionnelle: insertTruck.camera_fonctionnelle ?? null,
      dashcam: insertTruck.dashcam ?? null,
      dashcam_fonctionnelle: insertTruck.dashcam_fonctionnelle ?? null,
      numero_pda: insertTruck.numero_pda ?? null,
      pda_fonctionnel: insertTruck.pda_fonctionnel ?? null,
      materiel_requis: insertTruck.materiel_requis ?? null,
      test_ok: insertTruck.test_ok ?? null,
      
      // Colonnes d'action et observation
      champ_action: insertTruck.champ_action ?? null,
      observation: insertTruck.observation ?? null,
      
      // Statuts calculés
      ...status,
      
      // Metadata
      derniere_maj: new Date(),
      notes: insertTruck.notes ?? null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.trucks.set(id, truck);
    return truck;
  }

  async updateTruck(id: string, updateData: Partial<InsertTruck>): Promise<Truck | undefined> {
    const existingTruck = this.trucks.get(id);
    if (!existingTruck) return undefined;

    const updatedTruckData = { ...existingTruck, ...updateData };
    const status = calculateTruckStatus(updatedTruckData);
    
    const updatedTruck: Truck = {
      ...updatedTruckData,
      ...status,
      derniere_maj: new Date(),
      updatedAt: new Date()
    };
    
    this.trucks.set(id, updatedTruck);
    return updatedTruck;
  }

  async deleteTruck(id: string): Promise<boolean> {
    return this.trucks.delete(id);
  }

  async searchTrucks(query: string): Promise<Truck[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.trucks.values()).filter(truck =>
      truck.immatriculation.toLowerCase().includes(lowerQuery) ||
      truck.modele.toLowerCase().includes(lowerQuery) ||
      truck.marque.toLowerCase().includes(lowerQuery)
    );
  }

  // Scraping config methods
  async getScrapingConfigs(): Promise<ScrapingConfig[]> {
    return Array.from(this.scrapingConfigs.values());
  }

  async createScrapingConfig(insertConfig: InsertScrapingConfig): Promise<ScrapingConfig> {
    const id = randomUUID();
    const config: ScrapingConfig = {
      id,
      nom: insertConfig.nom,
      url: insertConfig.url,
      selecteur_css: insertConfig.selecteur_css,
      modele_ia: insertConfig.modele_ia ?? null,
      frequence: insertConfig.frequence ?? null,
      actif: insertConfig.actif ?? null,
      derniere_execution: null,
      createdAt: new Date()
    };
    this.scrapingConfigs.set(id, config);
    return config;
  }

  async updateScrapingConfig(id: string, updateData: Partial<InsertScrapingConfig>): Promise<ScrapingConfig | undefined> {
    const existingConfig = this.scrapingConfigs.get(id);
    if (!existingConfig) return undefined;

    const updatedConfig: ScrapingConfig = {
      ...existingConfig,
      ...updateData
    };
    
    this.scrapingConfigs.set(id, updatedConfig);
    return updatedConfig;
  }

  async deleteScrapingConfig(id: string): Promise<boolean> {
    return this.scrapingConfigs.delete(id);
  }

  // Social mention methods
  async getSocialMentions(): Promise<SocialMention[]> {
    return Array.from(this.socialMentions.values());
  }

  async createSocialMention(insertMention: InsertSocialMention): Promise<SocialMention> {
    const id = randomUUID();
    const mention: SocialMention = {
      id,
      plateforme: insertMention.plateforme,
      contenu: insertMention.contenu,
      auteur: insertMention.auteur ?? null,
      url: insertMention.url ?? null,
      sentiment: insertMention.sentiment ?? null,
      immatriculation_mentionnee: insertMention.immatriculation_mentionnee ?? null,
      date_mention: insertMention.date_mention ?? new Date(),
      createdAt: new Date()
    };
    this.socialMentions.set(id, mention);
    return mention;
  }

  // Equipment methods
  async getEquipements(): Promise<Equipement[]> {
    return Array.from(this.equipements.values());
  }

  async createEquipement(insertEquipement: InsertEquipement): Promise<Equipement> {
    const id = randomUUID();
    const equipement: Equipement = {
      id,
      nom: insertEquipement.nom,
      type: insertEquipement.type,
      numero_serie: insertEquipement.numero_serie ?? null,
      immatriculation_camion: insertEquipement.immatriculation_camion ?? null,
      statut: insertEquipement.statut ?? null,
      derniere_sync: insertEquipement.derniere_sync ?? null,
      niveau_batterie: insertEquipement.niveau_batterie ?? null,
      version_app: insertEquipement.version_app ?? null,
      createdAt: new Date()
    };
    this.equipements.set(id, equipement);
    return equipement;
  }

  async updateEquipement(id: string, updateData: Partial<InsertEquipement>): Promise<Equipement | undefined> {
    const existingEquipement = this.equipements.get(id);
    if (!existingEquipement) return undefined;

    const updatedEquipement: Equipement = {
      ...existingEquipement,
      ...updateData
    };
    
    this.equipements.set(id, updatedEquipement);
    return updatedEquipement;
  }

  async deleteEquipement(id: string): Promise<boolean> {
    return this.equipements.delete(id);
  }
}

export const storage = new MemStorage();