import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Plus, Upload, Download, Truck as TruckIcon, Settings, Activity, DollarSign, Smartphone, Worm } from "lucide-react";
import StatusCards from "@/components/status-cards";
import TruckTable from "@/components/truck-table";
import TruckForm from "@/components/truck-form";
import ScrapingTab from "@/components/scraping-tab";
import FinancialTab from "@/components/financial-tab";
import Truck4UTab from "@/components/truck4u-tab";
import TabletteTab from "@/components/tablette-tab";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { useQuery } from "@tanstack/react-query";
import { type Truck } from "@shared/schema";

type Tab = "suivi" | "scraping" | "financial" | "truck4u" | "tablette";

const tabConfig = {
  suivi: { title: "Suivi Principal", icon: TruckIcon },
  scraping: { title: "Web Scraping", icon: Worm },
  financial: { title: "Financial", icon: DollarSign },
  truck4u: { title: "Truck4U", icon: Settings },
  tablette: { title: "Tablette", icon: Smartphone }
};

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<Tab>("suivi");
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);

  const { data: trucks = [], isLoading } = useQuery<Truck[]>({
    queryKey: ["/api/trucks"],
  });

  const { data: stats } = useQuery<{
    totalTrucks: number;
    okCount: number;
    problemCount: number;
    pendingCount: number;
  }>({
    queryKey: ["/api/stats"],
  });

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const filteredTrucks = trucks.filter(truck =>
    truck.immatriculation.toLowerCase().includes(searchQuery.toLowerCase()) ||
    truck.modele.toLowerCase().includes(searchQuery.toLowerCase()) ||
    truck.marque.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case "suivi":
        return (
          <div className="space-y-6">
            <StatusCards stats={stats} />
            <TruckTable trucks={filteredTrucks} isLoading={isLoading} />
          </div>
        );
      case "scraping":
        return <ScrapingTab />;
      case "financial":
        return <FinancialTab />;
      case "truck4u":
        return <Truck4UTab />;
      case "tablette":
        return <TabletteTab />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-lg flex flex-col">
        <div className="p-6">
          <h1 className="text-xl font-bold text-gray-800 mb-2">Gestionnaire de Données</h1>
          <p className="text-sm text-gray-600">Outil de Scraping & Suivi</p>
        </div>
        
        <nav className="flex-1 px-4">
          <ul className="space-y-2">
            {Object.entries(tabConfig).map(([tab, config]) => {
              const Icon = config.icon;
              const isActive = activeTab === tab;
              return (
                <li key={tab}>
                  <button
                    onClick={() => setActiveTab(tab as Tab)}
                    className={`w-full text-left px-4 py-2 rounded-lg transition-colors flex items-center ${
                      isActive
                        ? "bg-blue-50 text-blue-600"
                        : "text-gray-700 hover:bg-blue-50 hover:text-blue-600"
                    }`}
                  >
                    <Icon className="w-5 h-5 mr-3" />
                    {config.title}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="p-4 border-t">
          <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
            <Download className="w-4 h-4 mr-2" />
            Export Excel
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Bar */}
        <header className="bg-white shadow-sm border-b px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <h2 className="text-2xl font-semibold text-gray-800">
                {tabConfig[activeTab].title}
              </h2>
              {stats && (
                <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                  {stats.totalTrucks} enregistrements
                </span>
              )}
            </div>
            <div className="flex items-center space-x-3">
              {/* Search Bar */}
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Rechercher par immatriculation..."
                  value={searchQuery}
                  onChange={(e) => handleSearch(e.target.value)}
                  className="pl-10 w-64"
                />
                <Search className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
              </div>
              
              {/* Actions */}
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-green-600 hover:bg-green-700 text-white">
                    <Plus className="w-4 h-4 mr-2" />
                    Ajouter
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Ajouter un nouveau camion</DialogTitle>
                    <DialogDescription>
                      Remplissez les informations pour créer un nouveau camion
                    </DialogDescription>
                  </DialogHeader>
                  <TruckForm onSuccess={() => setIsAddDialogOpen(false)} />
                </DialogContent>
              </Dialog>
              
              <Button variant="outline" className="bg-gray-600 text-white hover:bg-gray-700">
                <Upload className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </header>

        {/* Tab Content */}
        <main className="flex-1 p-6 overflow-auto">
          {renderTabContent()}
        </main>
      </div>
    </div>
  );
}
