import { type Truck } from "@shared/schema";

export type StatusColor = "vert" | "rouge" | "gris";

export function calculateEtatStatus(truck: Truck): StatusColor {
  // Si pas de données de base, retourner gris
  if (!truck.numero_demande_achat && !truck.numero_commande_achat) {
    return "gris";
  }
  
  // Vérifier les éléments critiques
  const hasValidDA = truck.da_valide === true;
  const hasValidReception = truck.validation_bonne_reception === true;
  
  if (truck.numero_demande_achat && truck.numero_commande_achat && hasValidDA && hasValidReception) {
    return "vert";
  }
  
  if (truck.numero_demande_achat || truck.numero_commande_achat) {
    return "rouge";
  }
  
  return "gris";
}

export function calculateTruck4UStatus(truck: Truck): StatusColor {
  // Si pas d'installation prévue, retourner gris
  if (!truck.installe_par && !truck.numero_truck4u) {
    return "gris";
  }
  
  // Vérifier les éléments critiques
  const hasInstallation = truck.installe_par && truck.date_installation_truck4u;
  const hasParametrage = truck.parametrage_realise === true;
  const isLocationFunctional = truck.donnees_localisation_fonctionnelles === true;
  const isDrivingStatusFunctional = truck.remontees_statut_conduite_fonctionnelles === true;
  const isMassDownloadFunctional = truck.telechargement_memoire_masse_fonctionnel === true;
  
  if (hasInstallation && hasParametrage && isLocationFunctional && isDrivingStatusFunctional && isMassDownloadFunctional) {
    return "vert";
  }
  
  if (truck.installe_par || truck.numero_truck4u) {
    return "rouge";
  }
  
  return "gris";
}

export function calculateTabletteStatus(truck: Truck): StatusColor {
  // Si pas de tablette prévue, retourner gris
  if (truck.tablette_presente === false || truck.tablette_presente === null) {
    return "gris";
  }
  
  // Si tablette présente, vérifier les fonctionnalités
  if (truck.tablette_presente === true) {
    const isFunctional = truck.tablette_fonctionnelle === true;
    const isCompatible = truck.compatibilite_tablette === true;
    const deliverUpOk = truck.besoin_appli_deliverup ? truck.deliverup_fonctionnel === true : true;
    
    if (isFunctional && isCompatible && deliverUpOk) {
      return "vert";
    } else {
      return "rouge";
    }
  }
  
  return "gris";
}

export function calculateMaterielStatus(truck: Truck): StatusColor {
  // Compter les équipements présents
  const equipements = [
    truck.camera_cabine_telematics,
    truck.dashcam,
    truck.numero_pda
  ];
  
  const hasAnyEquipment = equipements.some(eq => eq === true || (typeof eq === 'string' && eq.length > 0));
  
  if (!hasAnyEquipment) {
    return "gris";
  }
  
  // Vérifier le fonctionnement des équipements présents
  const functionalChecks = [];
  
  if (truck.camera_cabine_telematics) {
    functionalChecks.push(truck.camera_fonctionnelle === true);
  }
  
  if (truck.dashcam) {
    functionalChecks.push(truck.dashcam_fonctionnelle === true);
  }
  
  if (truck.numero_pda && truck.numero_pda.length > 0) {
    functionalChecks.push(truck.pda_fonctionnel === true);
  }
  
  const testResult = truck.test_ok === true;
  
  if (functionalChecks.length > 0 && functionalChecks.every(check => check) && testResult) {
    return "vert";
  }
  
  if (functionalChecks.length > 0) {
    return "rouge";
  }
  
  return "gris";
}

export function calculateGlobalStatus(truck: Truck): StatusColor {
  const etatStatus = calculateEtatStatus(truck);
  const truck4uStatus = calculateTruck4UStatus(truck);
  const tabletteStatus = calculateTabletteStatus(truck);
  const materielStatus = calculateMaterielStatus(truck);
  
  const statuses = [etatStatus, truck4uStatus, tabletteStatus, materielStatus];
  
  // Si tout est gris (pas besoin), retourner gris
  if (statuses.every(status => status === "gris")) {
    return "gris";
  }
  
  // Si au moins un rouge, retourner rouge
  if (statuses.some(status => status === "rouge")) {
    return "rouge";
  }
  
  // Si au moins un vert et aucun rouge, retourner vert
  if (statuses.some(status => status === "vert")) {
    return "vert";
  }
  
  return "gris";
}

export function calculateAllStatuses(truck: Truck): {
  statut_etat: StatusColor;
  statut_truck4u: StatusColor;
  statut_tablette: StatusColor;
  statut_materiel: StatusColor;
  statut_global: StatusColor;
} {
  return {
    statut_etat: calculateEtatStatus(truck),
    statut_truck4u: calculateTruck4UStatus(truck),
    statut_tablette: calculateTabletteStatus(truck),
    statut_materiel: calculateMaterielStatus(truck),
    statut_global: calculateGlobalStatus(truck)
  };
}

export function getStatusColor(status: StatusColor): string {
  switch (status) {
    case "vert":
      return "bg-green-100 text-green-800 border-green-200";
    case "rouge":
      return "bg-red-100 text-red-800 border-red-200";
    case "gris":
      return "bg-gray-100 text-gray-600 border-gray-200";
    default:
      return "bg-gray-100 text-gray-600 border-gray-200";
  }
}

export function getStatusText(status: StatusColor): string {
  switch (status) {
    case "vert":
      return "OK";
    case "rouge":
      return "Problème";
    case "gris":
      return "N/A";
    default:
      return "N/A";
  }
}