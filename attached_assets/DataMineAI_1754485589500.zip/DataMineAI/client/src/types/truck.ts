export interface TruckStats {
  totalTrucks: number;
  okCount: number;
  problemCount: number;
  pendingCount: number;
}

export interface TruckFilters {
  search: string;
  status?: "vert" | "rouge" | "gris";
  hasProblems?: boolean;
}

export interface TableSortConfig {
  field: string;
  direction: "asc" | "desc";
}
