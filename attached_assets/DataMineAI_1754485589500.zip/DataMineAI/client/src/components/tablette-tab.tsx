import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Plus, Settings, FileText, Tablet, FolderSync, Battery, Wifi } from "lucide-react";

export default function TabletteTab() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Equipment Management */}
        <Card>
          <CardHeader>
            <CardTitle>Gestion des Équipements</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center py-8 text-gray-500">
              <Tablet className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>Aucun équipement configuré</p>
              <p className="text-sm">Ajoutez des tablettes ou équipements mobiles</p>
            </div>
            
            <Button className="w-full bg-green-600 hover:bg-green-700">
              <Plus className="w-4 h-4 mr-2" />
              Ajouter Équipement
            </Button>
          </CardContent>
        </Card>
        
        {/* Mobile App Configuration */}
        <Card>
          <CardHeader>
            <CardTitle>Configuration Application Mobile</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Version de l'App</label>
              <Select defaultValue="v2.4.1">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="v2.4.1">v2.4.1 (Dernière)</SelectItem>
                  <SelectItem value="v2.4.0">v2.4.0</SelectItem>
                  <SelectItem value="v2.3.9">v2.3.9</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Fréquence de sync</label>
              <Select defaultValue="real-time">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="real-time">Temps réel</SelectItem>
                  <SelectItem value="5min">Toutes les 5 minutes</SelectItem>
                  <SelectItem value="15min">Toutes les 15 minutes</SelectItem>
                  <SelectItem value="30min">Toutes les 30 minutes</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700">Mode offline</span>
              <Switch defaultChecked />
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700">Notifications push</span>
              <Switch defaultChecked />
            </div>
            
            <Button className="w-full bg-blue-600 hover:bg-blue-700">
              Sauvegarder Configuration
            </Button>
          </CardContent>
        </Card>
      </div>
      
      {/* Device Stats */}
      <Card>
        <CardHeader>
          <CardTitle>Statistiques des Appareils</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 border border-gray-200 rounded-lg">
              <Tablet className="w-8 h-8 text-blue-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-gray-800">0</p>
              <p className="text-sm text-gray-600">Appareils Actifs</p>
            </div>
            
            <div className="text-center p-4 border border-gray-200 rounded-lg">
              <FolderSync className="w-8 h-8 text-green-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-gray-800">0%</p>
              <p className="text-sm text-gray-600">Taux de FolderSync</p>
            </div>
            
            <div className="text-center p-4 border border-gray-200 rounded-lg">
              <Battery className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-gray-800">0%</p>
              <p className="text-sm text-gray-600">Batterie Moyenne</p>
            </div>
            
            <div className="text-center p-4 border border-gray-200 rounded-lg">
              <Wifi className="w-8 h-8 text-purple-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-gray-800">0/0</p>
              <p className="text-sm text-gray-600">Connectés</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
