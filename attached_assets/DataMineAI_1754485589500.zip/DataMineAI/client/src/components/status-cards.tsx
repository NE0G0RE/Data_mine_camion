import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, AlertTriangle, Clock, Truck } from "lucide-react";

interface StatsData {
  totalTrucks: number;
  okCount: number;
  problemCount: number;
  pendingCount: number;
}

interface StatusCardsProps {
  stats?: StatsData;
}

export default function StatusCards({ stats }: StatusCardsProps) {
  if (!stats) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-4">
              <div className="h-16 bg-gray-200 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: "Statut OK",
      value: stats.okCount,
      icon: CheckCircle,
      color: "status-ok",
      borderColor: "border-status-ok"
    },
    {
      title: "Problèmes",
      value: stats.problemCount,
      icon: AlertTriangle,
      color: "status-problem",
      borderColor: "border-status-problem"
    },
    {
      title: "En attente",
      value: stats.pendingCount,
      icon: Clock,
      color: "status-neutral",
      borderColor: "border-status-neutral"
    },
    {
      title: "Total Camions",
      value: stats.totalTrucks,
      icon: Truck,
      color: "text-blue-600",
      borderColor: "border-blue-500"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      {cards.map((card, index) => {
        const Icon = card.icon;
        return (
          <Card key={index} className={`border-l-4 ${card.borderColor}`}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">{card.title}</p>
                  <p className={`text-2xl font-bold ${card.color}`}>{card.value}</p>
                </div>
                <Icon className={`h-8 w-8 ${card.color}`} />
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
