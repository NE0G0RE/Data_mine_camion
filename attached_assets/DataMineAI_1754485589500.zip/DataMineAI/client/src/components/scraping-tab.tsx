import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Play, AlertCircle, Lightbulb, Activity } from "lucide-react";

export default function ScrapingTab() {
  const [isActive, setIsActive] = useState(false);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Scraping Configuration */}
        <Card>
          <CardHeader>
            <CardTitle>Configuration du Scraping</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">URL Cible</label>
              <Input type="url" placeholder="https://example.com" />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Sélecteur CSS</label>
              <Input type="text" placeholder="div.truck-info" />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Modèle d'IA</label>
              <Select defaultValue="gpt-4-turbo">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gpt-4-turbo">GPT-4 Turbo</SelectItem>
                  <SelectItem value="claude-3-5-sonnet">Claude 3.5 Sonnet</SelectItem>
                  <SelectItem value="gemini-pro">Gemini Pro</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Fréquence</label>
              <Select defaultValue="temps-reel">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="temps-reel">Temps réel</SelectItem>
                  <SelectItem value="hourly">Toutes les heures</SelectItem>
                  <SelectItem value="daily">Quotidien</SelectItem>
                  <SelectItem value="weekly">Hebdomadaire</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button 
              className="w-full bg-blue-600 hover:bg-blue-700"
              onClick={() => setIsActive(!isActive)}
            >
              <Play className="w-4 h-4 mr-2" />
              {isActive ? "Arrêter" : "Démarrer"} le Scraping
            </Button>
          </CardContent>
        </Card>
        
        {/* Real-time Results */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Résultats en Temps Réel</CardTitle>
              <Badge className={isActive ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                <div className={`w-2 h-2 rounded-full mr-2 ${isActive ? "bg-green-500 animate-pulse" : "bg-gray-500"}`} />
                {isActive ? "Actif" : "Inactif"}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {isActive ? (
                <>
                  <div className="p-3 border border-gray-200 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-800">Scanning en cours...</p>
                        <p className="text-xs text-gray-600 mt-1">Recherche de nouvelles données</p>
                        <p className="text-xs text-gray-500 mt-1">Source: transport-data.com</p>
                      </div>
                      <span className="text-xs text-gray-500">Maintenant</span>
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Activity className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>Démarrez le scraping pour voir les résultats</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* AI Analysis Section */}
      <Card>
        <CardHeader>
          <CardTitle>Analyse IA des Données</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 border border-blue-200 rounded-lg bg-blue-50">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-blue-600 font-medium">Anomalies Détectées</p>
                  <p className="text-2xl font-bold text-blue-700">0</p>
                </div>
                <AlertCircle className="h-8 w-8 text-blue-500" />
              </div>
            </div>
            
            <div className="p-4 border border-green-200 rounded-lg bg-green-50">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-600 font-medium">Recommandations</p>
                  <p className="text-2xl font-bold text-green-700">0</p>
                </div>
                <Lightbulb className="h-8 w-8 text-green-500" />
              </div>
            </div>
            
            <div className="p-4 border border-purple-200 rounded-lg bg-purple-50">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-purple-600 font-medium">Prédictions</p>
                  <p className="text-2xl font-bold text-purple-700">0</p>
                </div>
                <Activity className="h-8 w-8 text-purple-500" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
