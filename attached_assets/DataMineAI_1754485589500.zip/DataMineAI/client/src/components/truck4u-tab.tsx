import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export default function Truck4UTab() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Données Truck4U</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Configuration */}
          <div>
            <h4 className="font-medium text-gray-800 mb-3">Configuration API</h4>
            <div className="space-y-3">
              <div>
                <label className="block text-sm text-gray-600 mb-1">Endpoint API</label>
                <Input 
                  type="text" 
                  placeholder="https://api.truck4u.com/v1/" 
                  defaultValue="https://api.truck4u.com/v1/"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-600 mb-1">Fréquence de sync</label>
                <Select defaultValue="real-time">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="real-time">Temps réel</SelectItem>
                    <SelectItem value="hourly">Toutes les heures</SelectItem>
                    <SelectItem value="daily">Quotidien</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                Tester la Connexion
              </Button>
            </div>
          </div>
          
          {/* Sync Status */}
          <div>
            <h4 className="font-medium text-gray-800 mb-3">État de Synchronisation</h4>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                <span className="text-sm text-gray-700">Dernière sync</span>
                <span className="text-sm text-gray-500">Non configuré</span>
              </div>
              <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                <span className="text-sm text-gray-700">Enregistrements sync</span>
                <span className="text-sm text-gray-500">0/0</span>
              </div>
              <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                <span className="text-sm text-gray-700">Erreurs</span>
                <span className="text-sm text-gray-500">0</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Data Mapping */}
        <div className="mt-6">
          <h4 className="font-medium text-gray-800 mb-3">Correspondance des Champs</h4>
          <div className="overflow-x-auto">
            <table className="w-full border border-gray-200 rounded-lg">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Champ Local</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Champ Truck4U</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Type</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Statut</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr>
                  <td className="px-4 py-2 text-sm">Immatriculation</td>
                  <td className="px-4 py-2 text-sm">license_plate</td>
                  <td className="px-4 py-2 text-sm">String</td>
                  <td className="px-4 py-2">
                    <Badge className="bg-green-100 text-green-800">Mappé</Badge>
                  </td>
                </tr>
                <tr>
                  <td className="px-4 py-2 text-sm">Modèle</td>
                  <td className="px-4 py-2 text-sm">vehicle_model</td>
                  <td className="px-4 py-2 text-sm">String</td>
                  <td className="px-4 py-2">
                    <Badge className="bg-green-100 text-green-800">Mappé</Badge>
                  </td>
                </tr>
                <tr>
                  <td className="px-4 py-2 text-sm">Marque</td>
                  <td className="px-4 py-2 text-sm">vehicle_brand</td>
                  <td className="px-4 py-2 text-sm">String</td>
                  <td className="px-4 py-2">
                    <Badge className="bg-green-100 text-green-800">Mappé</Badge>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
