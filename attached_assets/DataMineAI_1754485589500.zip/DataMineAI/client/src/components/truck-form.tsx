import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { insertTruckSchema, type Truck } from "@shared/schema";
import { calculateAllStatuses } from "@/lib/status-calculator";
import { useToast } from "@/hooks/use-toast";

interface TruckFormProps {
  truck?: Truck;
  onSuccess?: () => void;
}

const installateurOptions = [
  "Technicien A",
  "Technicien B", 
  "Prestataire externe",
  "Service interne"
];

const typeTabletteOptions = [
  "Samsung Galaxy Tab A",
  "iPad",
  "Tablette Android générique",
  "Tablette Windows",
  "Autre"
];

export default function TruckForm({ truck, onSuccess }: TruckFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm({
    resolver: zodResolver(insertTruckSchema),
    defaultValues: {
      immatriculation: truck?.immatriculation || "",
      modele: truck?.modele || "",
      marque: truck?.marque || "",
      
      // État
      numero_demande_achat: truck?.numero_demande_achat || "",
      date_demande_achat: truck?.date_demande_achat || null,
      da_valide: truck?.da_valide || false,
      numero_commande_achat: truck?.numero_commande_achat || "",
      date_commande_achat: truck?.date_commande_achat || null,
      date_reception_commande: truck?.date_reception_commande || null,
      validation_bonne_reception: truck?.validation_bonne_reception || false,
      
      // État Truck4U
      installe_par: truck?.installe_par || "",
      date_installation_truck4u: truck?.date_installation_truck4u || null,
      parametrage_realise: truck?.parametrage_realise || false,
      parametrage_par: truck?.parametrage_par || "",
      donnees_localisation_fonctionnelles: truck?.donnees_localisation_fonctionnelles || false,
      remontees_statut_conduite_fonctionnelles: truck?.remontees_statut_conduite_fonctionnelles || false,
      telechargement_memoire_masse_fonctionnel: truck?.telechargement_memoire_masse_fonctionnel || false,
      numero_truck4u: truck?.numero_truck4u || "",
      
      // État Tablette
      tablette_presente: truck?.tablette_presente || false,
      type_tablette: truck?.type_tablette || "",
      imei_tablette: truck?.imei_tablette || "",
      tablette_fonctionnelle: truck?.tablette_fonctionnelle || false,
      compatibilite_tablette: truck?.compatibilite_tablette || false,
      besoin_appli_deliverup: truck?.besoin_appli_deliverup || false,
      deliverup_fonctionnel: truck?.deliverup_fonctionnel || false,
      application_specifique_client: truck?.application_specifique_client || "",
      raison_non_installe: truck?.raison_non_installe || "",
      besoin_autre_appli: truck?.besoin_autre_appli || false,
      autre_appli_installee: truck?.autre_appli_installee || "",
      
      // État Matériel
      camera_cabine_telematics: truck?.camera_cabine_telematics || false,
      camera_fonctionnelle: truck?.camera_fonctionnelle || false,
      dashcam: truck?.dashcam || false,
      dashcam_fonctionnelle: truck?.dashcam_fonctionnelle || false,
      numero_pda: truck?.numero_pda || "",
      pda_fonctionnel: truck?.pda_fonctionnel || false,
      materiel_requis: truck?.materiel_requis || "",
      test_ok: truck?.test_ok || false,
      
      // Colonnes d'action
      champ_action: truck?.champ_action || "",
      observation: truck?.observation || "",
      notes: truck?.notes || "",
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => {
      const statuses = calculateAllStatuses(data);
      const truckData = { ...data, ...statuses };
      return apiRequest("/api/trucks", "POST", truckData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/trucks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({ title: "Camion créé avec succès" });
      onSuccess?.();
    },
    onError: () => {
      toast({ title: "Erreur lors de la création", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data: any) => {
      const statuses = calculateAllStatuses(data);
      const truckData = { ...data, ...statuses };
      return apiRequest(`/api/trucks/${truck?.id}`, "PATCH", truckData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/trucks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({ title: "Camion mis à jour avec succès" });
      onSuccess?.();
    },
    onError: () => {
      toast({ title: "Erreur lors de la mise à jour", variant: "destructive" });
    },
  });

  const onSubmit = (data: any) => {
    if (truck) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const formatDateForInput = (date: string | Date | null) => {
    if (!date) return "";
    const d = new Date(date);
    return d.toISOString().split('T')[0];
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        {/* Informations de base */}
        <Card>
          <CardHeader>
            <CardTitle>Informations de base</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <FormField
              control={form.control}
              name="immatriculation"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Immatriculation</FormLabel>
                  <FormControl>
                    <Input placeholder="AA-123-BB" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="marque"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Marque</FormLabel>
                  <FormControl>
                    <Input placeholder="Renault" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="modele"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Modèle</FormLabel>
                  <FormControl>
                    <Input placeholder="Master" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
        </Card>

        <Tabs defaultValue="etat" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="etat">État</TabsTrigger>
            <TabsTrigger value="truck4u">Truck4U</TabsTrigger>
            <TabsTrigger value="tablette">Tablette</TabsTrigger>
            <TabsTrigger value="materiel">Matériel</TabsTrigger>
          </TabsList>

          {/* État - Demande d'Achat et Commande */}
          <TabsContent value="etat">
            <Card>
              <CardHeader>
                <CardTitle>État - Demande d'Achat et Commande</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="numero_demande_achat"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>N° de Demande d'Achat</FormLabel>
                        <FormControl>
                          <Input placeholder="DA-2024-001" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="date_demande_achat"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Date de Demande d'Achat</FormLabel>
                        <FormControl>
                          <Input 
                            type="date" 
                            {...field} 
                            value={formatDateForInput(field.value)}
                            onChange={(e) => field.onChange(e.target.value ? new Date(e.target.value) : null)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="da_valide"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>DA validé?</FormLabel>
                      </div>
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="numero_commande_achat"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>N° de Commande d'Achat</FormLabel>
                        <FormControl>
                          <Input placeholder="CA-2024-001" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="date_commande_achat"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Date de Commande d'Achat</FormLabel>
                        <FormControl>
                          <Input 
                            type="date" 
                            {...field} 
                            value={formatDateForInput(field.value)}
                            onChange={(e) => field.onChange(e.target.value ? new Date(e.target.value) : null)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="date_reception_commande"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date de réception de la commande</FormLabel>
                      <FormControl>
                        <Input 
                          type="date" 
                          {...field} 
                          value={formatDateForInput(field.value)}
                          onChange={(e) => field.onChange(e.target.value ? new Date(e.target.value) : null)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="validation_bonne_reception"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Validation de bonne réception de la commande</FormLabel>
                      </div>
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* État Truck4U */}
          <TabsContent value="truck4u">
            <Card>
              <CardHeader>
                <CardTitle>État Truck4U</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="installe_par"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Installé par</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Sélectionner un installateur" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {installateurOptions.map((option) => (
                              <SelectItem key={option} value={option}>
                                {option}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="date_installation_truck4u"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Date d'installation</FormLabel>
                        <FormControl>
                          <Input 
                            type="date" 
                            {...field} 
                            value={formatDateForInput(field.value)}
                            onChange={(e) => field.onChange(e.target.value ? new Date(e.target.value) : null)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="parametrage_realise"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Paramétrage réalisé</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="parametrage_par"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Paramétrage par</FormLabel>
                        <FormControl>
                          <Input placeholder="Nom du technicien" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="donnees_localisation_fonctionnelles"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Données de localisation fonctionnelles</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="remontees_statut_conduite_fonctionnelles"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Remontées de données de statut de conduite fonctionnelles</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="telechargement_memoire_masse_fonctionnel"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Téléchargement de mémoire de masse fonctionnel</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="numero_truck4u"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>N° de Truck4U</FormLabel>
                      <FormControl>
                        <Input placeholder="T4U-001" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* État Tablette */}
          <TabsContent value="tablette">
            <Card>
              <CardHeader>
                <CardTitle>État Tablette</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="tablette_presente"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Est-ce qu'il y a une tablette?</FormLabel>
                      </div>
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="type_tablette"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Type de tablette</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Sélectionner un type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {typeTabletteOptions.map((option) => (
                              <SelectItem key={option} value={option}>
                                {option}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="imei_tablette"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>IMEI de la tablette</FormLabel>
                        <FormControl>
                          <Input placeholder="123456789012345" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="tablette_fonctionnelle"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Tablette fonctionnelle</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="compatibilite_tablette"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Compatibilité de la tablette</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="besoin_appli_deliverup"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Besoin appli DeliverUp</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="deliverup_fonctionnel"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>DeliverUp fonctionnel</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="application_specifique_client"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Application spécifique demandée par le client</FormLabel>
                      <FormControl>
                        <Input placeholder="Nom de l'application" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="raison_non_installe"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Raison si non installé</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Expliquer pourquoi..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="besoin_autre_appli"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Besoin autre appli?</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="autre_appli_installee"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Autre appli installée</FormLabel>
                        <FormControl>
                          <Input placeholder="Nom de l'application" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* État Matériel */}
          <TabsContent value="materiel">
            <Card>
              <CardHeader>
                <CardTitle>État Matériel</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="camera_cabine_telematics"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Caméra cabine Telematics</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="camera_fonctionnelle"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Caméra fonctionnelle?</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="dashcam"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Dashcam</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="dashcam_fonctionnelle"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Dashcam fonctionnelle?</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="numero_pda"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Numéro de PDA</FormLabel>
                        <FormControl>
                          <Input placeholder="PDA-001" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="pda_fonctionnel"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>PDA fonctionnel</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="materiel_requis"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Matériel requis</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Description du matériel requis..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="test_ok"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Test OK?</FormLabel>
                      </div>
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Champ d'action et Observation */}
        <Card>
          <CardHeader>
            <CardTitle>Actions et Observations</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <FormField
              control={form.control}
              name="champ_action"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Champ d'action</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Actions à effectuer..." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="observation"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Observation</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Observations sur le camion..." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Notes supplémentaires..." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
        </Card>

        <div className="flex justify-end space-x-2">
          <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
            {createMutation.isPending || updateMutation.isPending ? "Enregistrement..." : "Enregistrer"}
          </Button>
        </div>
      </form>
    </Form>
  );
}