import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Edit, Eye, Trash2, ArrowUpDown } from "lucide-react";
import { Truck } from "@shared/schema";
import TruckForm from "./truck-form";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { getStatusColor, getStatusText, type StatusColor } from "@/lib/status-calculator";

interface TruckTableProps {
  trucks: Truck[];
  isLoading: boolean;
}

export default function TruckTable({ trucks, isLoading }: TruckTableProps) {
  const [editingTruck, setEditingTruck] = useState<Truck | null>(null);
  const [viewingTruck, setViewingTruck] = useState<Truck | null>(null);
  const [sortField, setSortField] = useState<keyof Truck>("immatriculation");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest(`/api/trucks/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/trucks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({ title: "Camion supprimé avec succès" });
    },
    onError: () => {
      toast({ title: "Erreur lors de la suppression", variant: "destructive" });
    },
  });

  const handleSort = (field: keyof Truck) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const sortedTrucks = [...trucks].sort((a, b) => {
    const aValue = a[sortField];
    const bValue = b[sortField];
    
    if (aValue === null || aValue === undefined) return 1;
    if (bValue === null || bValue === undefined) return -1;
    
    if (aValue < bValue) return sortDirection === "asc" ? -1 : 1;
    if (aValue > bValue) return sortDirection === "asc" ? 1 : -1;
    return 0;
  });

  const formatDate = (date: string | Date | null) => {
    if (!date) return "-";
    const d = new Date(date);
    return d.toLocaleDateString('fr-FR');
  };

  const safeGetStatusColor = (status: string | null): string => {
    return getStatusColor((status || "gris") as StatusColor);
  };

  const safeGetStatusText = (status: string | null): string => {
    return getStatusText((status || "gris") as StatusColor);
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">Chargement des camions...</div>
        </CardContent>
      </Card>
    );
  }

  if (!trucks.length) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-gray-500">
            Aucun camion trouvé. Commencez par ajouter un camion.
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleSort("immatriculation")}
                      className="h-auto p-0 font-semibold"
                    >
                      Immatriculation
                      <ArrowUpDown className="ml-1 h-3 w-3" />
                    </Button>
                  </th>
                  <th className="px-4 py-3 text-left">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleSort("marque")}
                      className="h-auto p-0 font-semibold"
                    >
                      Marque/Modèle
                      <ArrowUpDown className="ml-1 h-3 w-3" />
                    </Button>
                  </th>
                  <th className="px-4 py-3 text-center">État</th>
                  <th className="px-4 py-3 text-center">Truck4U</th>
                  <th className="px-4 py-3 text-center">Tablette</th>
                  <th className="px-4 py-3 text-center">Matériel</th>
                  <th className="px-4 py-3 text-center">Global</th>
                  <th className="px-4 py-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody>
                {sortedTrucks.map((truck) => (
                  <tr key={truck.id} className="border-b hover:bg-gray-50">
                    <td className="px-4 py-3 font-mono text-sm">
                      {truck.immatriculation}
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-medium">{truck.marque}</div>
                      <div className="text-sm text-gray-500">{truck.modele}</div>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <Badge
                        variant="outline"
                        className={safeGetStatusColor(truck.statut_etat)}
                      >
                        {safeGetStatusText(truck.statut_etat)}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <Badge
                        variant="outline"
                        className={safeGetStatusColor(truck.statut_truck4u)}
                      >
                        {safeGetStatusText(truck.statut_truck4u)}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <Badge
                        variant="outline"
                        className={safeGetStatusColor(truck.statut_tablette)}
                      >
                        {safeGetStatusText(truck.statut_tablette)}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <Badge
                        variant="outline"
                        className={safeGetStatusColor(truck.statut_materiel)}
                      >
                        {safeGetStatusText(truck.statut_materiel)}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <Badge
                        variant="outline"
                        className={safeGetStatusColor(truck.statut_global)}
                      >
                        {safeGetStatusText(truck.statut_global)}
                      </Badge>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex gap-2 justify-center">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setViewingTruck(truck)}
                          className="h-8 w-8 p-0"
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingTruck(truck)}
                          className="h-8 w-8 p-0"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteMutation.mutate(truck.id)}
                          disabled={deleteMutation.isPending}
                          className="h-8 w-8 p-0 text-red-600 hover:text-red-800"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={!!editingTruck} onOpenChange={() => setEditingTruck(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Modifier le camion</DialogTitle>
            <DialogDescription>
              Modifiez les informations du camion sélectionné
            </DialogDescription>
          </DialogHeader>
          {editingTruck && (
            <TruckForm
              truck={editingTruck}
              onSuccess={() => setEditingTruck(null)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={!!viewingTruck} onOpenChange={() => setViewingTruck(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Détails du camion</DialogTitle>
            <DialogDescription>
              Informations détaillées du camion sélectionné
            </DialogDescription>
          </DialogHeader>
          {viewingTruck && (
            <div className="space-y-6">
              {/* Informations de base */}
              <div>
                <h3 className="font-semibold mb-2">Informations générales</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Immatriculation:</span> {viewingTruck.immatriculation}
                  </div>
                  <div>
                    <span className="font-medium">Marque:</span> {viewingTruck.marque}
                  </div>
                  <div>
                    <span className="font-medium">Modèle:</span> {viewingTruck.modele}
                  </div>
                </div>
              </div>

              {/* État */}
              <div>
                <h3 className="font-semibold mb-2">État</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">N° DA:</span> {viewingTruck.numero_demande_achat || "-"}
                  </div>
                  <div>
                    <span className="font-medium">Date DA:</span> {formatDate(viewingTruck.date_demande_achat)}
                  </div>
                  <div>
                    <span className="font-medium">DA validé:</span> {viewingTruck.da_valide ? "Oui" : "Non"}
                  </div>
                  <div>
                    <span className="font-medium">N° CA:</span> {viewingTruck.numero_commande_achat || "-"}
                  </div>
                </div>
              </div>

              {/* Truck4U */}
              <div>
                <h3 className="font-semibold mb-2">Truck4U</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Installé par:</span> {viewingTruck.installe_par || "-"}
                  </div>
                  <div>
                    <span className="font-medium">Date installation:</span> {formatDate(viewingTruck.date_installation_truck4u)}
                  </div>
                  <div>
                    <span className="font-medium">Paramétrage:</span> {viewingTruck.parametrage_realise ? "Oui" : "Non"}
                  </div>
                  <div>
                    <span className="font-medium">N° Truck4U:</span> {viewingTruck.numero_truck4u || "-"}
                  </div>
                </div>
              </div>

              {/* Tablette */}
              <div>
                <h3 className="font-semibold mb-2">Tablette</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Présente:</span> {viewingTruck.tablette_presente ? "Oui" : "Non"}
                  </div>
                  <div>
                    <span className="font-medium">Type:</span> {viewingTruck.type_tablette || "-"}
                  </div>
                  <div>
                    <span className="font-medium">IMEI:</span> {viewingTruck.imei_tablette || "-"}
                  </div>
                  <div>
                    <span className="font-medium">Fonctionnelle:</span> {viewingTruck.tablette_fonctionnelle ? "Oui" : "Non"}
                  </div>
                </div>
              </div>

              {/* Matériel */}
              <div>
                <h3 className="font-semibold mb-2">Matériel</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Caméra cabine:</span> {viewingTruck.camera_cabine_telematics ? "Oui" : "Non"}
                  </div>
                  <div>
                    <span className="font-medium">Dashcam:</span> {viewingTruck.dashcam ? "Oui" : "Non"}
                  </div>
                  <div>
                    <span className="font-medium">N° PDA:</span> {viewingTruck.numero_pda || "-"}
                  </div>
                  <div>
                    <span className="font-medium">Test OK:</span> {viewingTruck.test_ok ? "Oui" : "Non"}
                  </div>
                </div>
              </div>

              {/* Actions et observations */}
              {(viewingTruck.champ_action || viewingTruck.observation || viewingTruck.notes) && (
                <div>
                  <h3 className="font-semibold mb-2">Actions et Observations</h3>
                  <div className="space-y-2 text-sm">
                    {viewingTruck.champ_action && (
                      <div>
                        <span className="font-medium">Champ d'action:</span>
                        <p className="mt-1 text-gray-600">{viewingTruck.champ_action}</p>
                      </div>
                    )}
                    {viewingTruck.observation && (
                      <div>
                        <span className="font-medium">Observation:</span>
                        <p className="mt-1 text-gray-600">{viewingTruck.observation}</p>
                      </div>
                    )}
                    {viewingTruck.notes && (
                      <div>
                        <span className="font-medium">Notes:</span>
                        <p className="mt-1 text-gray-600">{viewingTruck.notes}</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Statuts */}
              <div>
                <h3 className="font-semibold mb-2">Statuts</h3>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline" className={safeGetStatusColor(viewingTruck.statut_etat)}>
                    État: {safeGetStatusText(viewingTruck.statut_etat)}
                  </Badge>
                  <Badge variant="outline" className={safeGetStatusColor(viewingTruck.statut_truck4u)}>
                    Truck4U: {safeGetStatusText(viewingTruck.statut_truck4u)}
                  </Badge>
                  <Badge variant="outline" className={safeGetStatusColor(viewingTruck.statut_tablette)}>
                    Tablette: {safeGetStatusText(viewingTruck.statut_tablette)}
                  </Badge>
                  <Badge variant="outline" className={safeGetStatusColor(viewingTruck.statut_materiel)}>
                    Matériel: {safeGetStatusText(viewingTruck.statut_materiel)}
                  </Badge>
                  <Badge variant="outline" className={safeGetStatusColor(viewingTruck.statut_global)}>
                    Global: {safeGetStatusText(viewingTruck.statut_global)}
                  </Badge>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}