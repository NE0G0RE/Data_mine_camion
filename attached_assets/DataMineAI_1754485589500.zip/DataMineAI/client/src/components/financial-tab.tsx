import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CloudUploadIcon, Euro, CheckCircle, AlertTriangle, Clock, FileSpreadsheet } from "lucide-react";

export default function FinancialTab() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Import Section */}
        <Card>
          <CardHeader>
            <CardTitle>Import Données</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <CloudUploadIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-sm text-gray-600 mb-2">Glissez vos fichiers Excel/CSV ici</p>
              <Button className="bg-blue-600 hover:bg-blue-700">
                Sélectionner Fichiers
              </Button>
            </div>
            
            <div className="mt-4 space-y-2">
              <div className="text-sm text-gray-500">
                Aucun fichier importé récemment
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Payment Status */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Statut des Paiements</CardTitle>
                <Button variant="outline" size="sm">
                  Actualiser
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-gray-500">
                <FileSpreadsheet className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                <p>Aucune donnée financière</p>
                <p className="text-sm">Importez un fichier Excel/CSV pour voir les données de paiement</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Financial Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Mensuel</p>
                <p className="text-2xl font-bold text-gray-800">€0</p>
              </div>
              <Euro className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Paiements OK</p>
                <p className="text-2xl font-bold text-status-ok">0</p>
              </div>
              <CheckCircle className="h-8 w-8 text-status-ok" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">En Retard</p>
                <p className="text-2xl font-bold text-status-problem">0</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-status-problem" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">En Attente</p>
                <p className="text-2xl font-bold text-status-neutral">0</p>
              </div>
              <Clock className="h-8 w-8 text-status-neutral" />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
