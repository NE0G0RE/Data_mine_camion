import { sql } from "drizzle-orm";
import { pgTable, text, varchar, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const trucks = pgTable("trucks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  immatriculation: text("immatriculation").notNull().unique(),
  modele: text("modele").notNull(),
  marque: text("marque").notNull(),
  
  // État - Demande d'Achat et Commande
  numero_demande_achat: text("numero_demande_achat"),
  date_demande_achat: timestamp("date_demande_achat"),
  da_valide: boolean("da_valide"),
  numero_commande_achat: text("numero_commande_achat"),
  date_commande_achat: timestamp("date_commande_achat"),
  date_reception_commande: timestamp("date_reception_commande"),
  validation_bonne_reception: boolean("validation_bonne_reception"),
  
  // État Truck4U
  installe_par: text("installe_par"), // Menu déroulant
  date_installation_truck4u: timestamp("date_installation_truck4u"),
  parametrage_realise: boolean("parametrage_realise"),
  parametrage_par: text("parametrage_par"),
  donnees_localisation_fonctionnelles: boolean("donnees_localisation_fonctionnelles"),
  remontees_statut_conduite_fonctionnelles: boolean("remontees_statut_conduite_fonctionnelles"),
  telechargement_memoire_masse_fonctionnel: boolean("telechargement_memoire_masse_fonctionnel"),
  numero_truck4u: text("numero_truck4u"),
  
  // État Tablette
  tablette_presente: boolean("tablette_presente"),
  type_tablette: text("type_tablette"),
  imei_tablette: text("imei_tablette"),
  tablette_fonctionnelle: boolean("tablette_fonctionnelle"),
  compatibilite_tablette: boolean("compatibilite_tablette"),
  besoin_appli_deliverup: boolean("besoin_appli_deliverup"),
  deliverup_fonctionnel: boolean("deliverup_fonctionnel"),
  application_specifique_client: text("application_specifique_client"),
  raison_non_installe: text("raison_non_installe"),
  besoin_autre_appli: boolean("besoin_autre_appli"),
  autre_appli_installee: text("autre_appli_installee"),
  
  // État Matériel
  camera_cabine_telematics: boolean("camera_cabine_telematics"),
  camera_fonctionnelle: boolean("camera_fonctionnelle"),
  dashcam: boolean("dashcam"),
  dashcam_fonctionnelle: boolean("dashcam_fonctionnelle"),
  numero_pda: text("numero_pda"),
  pda_fonctionnel: boolean("pda_fonctionnel"),
  materiel_requis: text("materiel_requis"),
  test_ok: boolean("test_ok"),
  
  // Colonnes d'action et observation
  champ_action: text("champ_action"),
  observation: text("observation"),
  
  // Statuts calculés avec système de couleurs
  statut_etat: text("statut_etat").default("gris"), // vert=ok, rouge=pas ok, gris=pas besoin
  statut_truck4u: text("statut_truck4u").default("gris"),
  statut_tablette: text("statut_tablette").default("gris"),
  statut_materiel: text("statut_materiel").default("gris"),
  statut_global: text("statut_global").default("gris"),
  
  // Metadata
  derniere_maj: timestamp("derniere_maj").defaultNow(),
  notes: text("notes"),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const scrapingConfigs = pgTable("scraping_configs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nom: text("nom").notNull(),
  url: text("url").notNull(),
  selecteur_css: text("selecteur_css").notNull(),
  modele_ia: text("modele_ia").default("gpt-4-turbo"),
  frequence: text("frequence").default("quotidien"),
  actif: boolean("actif").default(true),
  derniere_execution: timestamp("derniere_execution"),
  createdAt: timestamp("created_at").defaultNow()
});

export const socialMentions = pgTable("social_mentions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  plateforme: text("plateforme").notNull(),
  contenu: text("contenu").notNull(),
  auteur: text("auteur"),
  url: text("url"),
  sentiment: text("sentiment"),
  immatriculation_mentionnee: text("immatriculation_mentionnee"),
  date_mention: timestamp("date_mention").defaultNow(),
  createdAt: timestamp("created_at").defaultNow()
});

export const equipements = pgTable("equipements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nom: text("nom").notNull(),
  type: text("type").notNull(),
  numero_serie: text("numero_serie"),
  immatriculation_camion: text("immatriculation_camion"),
  statut: text("statut").default("actif"),
  derniere_sync: timestamp("derniere_sync"),
  niveau_batterie: text("niveau_batterie"),
  version_app: text("version_app"),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertTruckSchema = createInsertSchema(trucks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  derniere_maj: true,
  statut_etat: true,
  statut_truck4u: true,
  statut_tablette: true,
  statut_materiel: true,
  statut_global: true
});

export const insertScrapingConfigSchema = createInsertSchema(scrapingConfigs).omit({
  id: true,
  createdAt: true,
  derniere_execution: true
});

export const insertSocialMentionSchema = createInsertSchema(socialMentions).omit({
  id: true,
  createdAt: true
});

export const insertEquipementSchema = createInsertSchema(equipements).omit({
  id: true,
  createdAt: true
});

export type InsertTruck = z.infer<typeof insertTruckSchema>;
export type Truck = typeof trucks.$inferSelect;
export type InsertScrapingConfig = z.infer<typeof insertScrapingConfigSchema>;
export type ScrapingConfig = typeof scrapingConfigs.$inferSelect;
export type InsertSocialMention = z.infer<typeof insertSocialMentionSchema>;
export type SocialMention = typeof socialMentions.$inferSelect;
export type InsertEquipement = z.infer<typeof insertEquipementSchema>;
export type Equipement = typeof equipements.$inferSelect;

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
