# Overview

This is a comprehensive truck fleet management system built as a full-stack web application. The system provides centralized tracking and monitoring of truck fleet operations including technical inspections, payment verification, administrative compliance, and equipment management. The application implements a status color-coding system (green/red/gray) similar to Google Sheets conditional formatting to provide quick visual status indicators for different aspects of truck management.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Framework**: shadcn/ui components built on Radix UI primitives with Tailwind CSS for styling
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod schema validation
- **Styling**: Tailwind CSS with custom CSS variables for theming and status colors

## Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **API Design**: RESTful API with JSON responses
- **Development**: Hot module replacement via Vite integration

## Data Storage Solutions
- **Database**: PostgreSQL via Neon serverless database
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Data Validation**: Zod schemas shared between client and server
- **Storage Interface**: Abstract storage layer with IStorage interface for future extensibility

## Key Features & Modules

### Truck Management System
- Complete CRUD operations for truck fleet
- Technical inspection tracking (brakes, tires, lighting, etc.)
- Insurance and payment verification
- Administrative compliance monitoring
- Equipment status tracking (tablets, GPS, cameras, sensors)
- Color-coded status system with automated calculation based on business rules

### Multi-Tab Dashboard Interface
- **Main Tracking Tab**: Primary truck management interface
- **Web Scraping Tab**: AI-powered data collection from external sources
- **Social Media Monitoring**: Social network mention tracking
- **Financial Integration**: Excel/CSV import capabilities
- **Truck4U Integration**: External API synchronization
- **Mobile Equipment Management**: Tablet and mobile device tracking

### Status Calculation Engine
- Implements complex business logic from Google Apps Script
- Color-coded status indicators (green=OK, red=problem, gray=pending)
- Hierarchical status calculation across multiple domains
- Real-time status updates based on data changes

## External Dependencies

### Database & ORM
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **drizzle-orm**: Type-safe ORM with PostgreSQL support
- **drizzle-kit**: Database migrations and schema management
- **connect-pg-simple**: PostgreSQL session store

### UI & Styling
- **@radix-ui/***: Comprehensive set of unstyled, accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe variant API for component styling
- **lucide-react**: Icon library

### Development & Build Tools
- **vite**: Fast build tool and development server
- **@vitejs/plugin-react**: React support for Vite
- **@replit/vite-plugin-***: Replit-specific development plugins
- **esbuild**: JavaScript bundler for production builds

### Form Management & Validation
- **react-hook-form**: Performant forms with minimal re-renders
- **@hookform/resolvers**: Validation resolvers for form schemas
- **zod**: TypeScript-first schema validation
- **drizzle-zod**: Integration between Drizzle ORM and Zod schemas

### Data Fetching & State
- **@tanstack/react-query**: Server state management and caching
- **date-fns**: Date manipulation and formatting utilities

The architecture follows a monorepo structure with shared schemas and clear separation between client, server, and shared code. The system is designed for scalability and maintainability with proper TypeScript support throughout and a flexible plugin architecture for extending functionality.